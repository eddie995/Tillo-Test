# Frontend Developer Task 2018

Please download/clone this repository and when you're complete, send the results back in a zip file.

The aim of these is to test your approach to solving the problems.

  - View the .html file in your browser to read the required task. 
  - Edit the HTML/JS directly to complete the task. 
  - The code should run in the latest versions of Chrome and Firefox.
  - How you complete the tasks is up to you.
  - It shouldn't take you more than 1 hour to complete.