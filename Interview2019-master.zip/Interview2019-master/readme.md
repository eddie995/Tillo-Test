# Reward Cloud Interview Tasks 2019

- If you're applying for one of our backend php roles, please see the readme in the "php" directory.
- Similarly if you're applying for one of our frontend roles, please see the readme in the "js" directory.
- Feel free to tackle both if you want to.
